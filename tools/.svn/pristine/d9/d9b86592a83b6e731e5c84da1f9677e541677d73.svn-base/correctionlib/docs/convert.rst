correctionlib.convert
---------------------
Conversion utilities for common alternative formats

.. currentmodule:: correctionlib.convert
.. autosummary::
    :toctree: _generated

    from_uproot_THx
    from_histogram
