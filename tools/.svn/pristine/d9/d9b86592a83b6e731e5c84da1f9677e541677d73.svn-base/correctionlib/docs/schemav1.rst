Schema v1
---------
First iteration of the schema

:download:`Download json <_generated/schemav1.json>`.

.. jsonschema:: _generated/schemav1.json
    :lift_description:
    :lift_definitions:
    :auto_target:
    :auto_reference:
