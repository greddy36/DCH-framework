correctionlib._core
-------------------
Pybind11 classes

.. currentmodule:: correctionlib._core
.. autosummary::
    :toctree: _generated

    Variable
    Correction
    CompoundCorrection
    CorrectionSet
